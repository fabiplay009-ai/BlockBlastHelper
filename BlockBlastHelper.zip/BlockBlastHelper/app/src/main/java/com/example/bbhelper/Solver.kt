package com.example.bbhelper

class Move(val piece: Int, val r: Int, val c: Int, val cells: List<IntArray>)
class Result(val moves: List<Move>, val lines: Int)

object Solver {
    private class Put(val b: BooleanArray, val n: Int)

    private fun put(b: BooleanArray, cells: List<IntArray>, r: Int, c: Int): Put? {
        for (x in cells) {
            val R = r + x[0]; val C = c + x[1]
            if (R > 7 || C > 7 || b[R * 8 + C]) return null
        }
        val n = b.copyOf()
        for (x in cells) n[(r + x[0]) * 8 + c + x[1]] = true
        val rows = BooleanArray(8); val cols = BooleanArray(8)
        var cnt = 0
        for (i in 0..7) {
            var a = true; var d = true
            for (j in 0..7) { if (!n[i * 8 + j]) a = false; if (!n[j * 8 + i]) d = false }
            rows[i] = a; cols[i] = d
            if (a) cnt++
            if (d) cnt++
        }
        for (i in 0..7) for (j in 0..7) if (rows[i] || cols[j]) n[i * 8 + j] = false
        return Put(n, cnt)
    }

    private fun eval(b: BooleanArray, lines: Int, placed: Int, total: Int): Double {
        var f = 0; var h = 0; var t = 0
        for (i in 0 until 64) {
            val r = i shr 3; val q = i and 7
            if (b[i]) f++ else {
                var e = 0
                if (r > 0 && !b[i - 8]) e++
                if (r < 7 && !b[i + 8]) e++
                if (q > 0 && !b[i - 1]) e++
                if (q < 7 && !b[i + 1]) e++
                if (e == 0) h++
            }
            if (q < 7 && b[i] != b[i + 1]) t++
            if (r < 7 && b[i] != b[i + 8]) t++
        }
        return lines * 20.0 - f * 1.5 - h * 6.0 - t * 1.2 - (total - placed) * 1000.0
    }

    private fun perms(a: List<Int>): List<List<Int>> =
        if (a.size < 2) listOf(a)
        else a.indices.flatMap { i -> perms(a.filterIndexed { j, _ -> j != i }).map { listOf(a[i]) + it } }

    fun solve(board: BooleanArray, pieces: List<List<IntArray>>): Result? {
        val ps = pieces.indices.filter { pieces[it].isNotEmpty() }
        if (ps.isEmpty()) return null
        var best = Double.NEGATIVE_INFINITY
        var res: Result? = null
        fun go(b: BooleanArray, pm: List<Int>, k: Int, mv: List<Move>, ln: Int) {
            var any = false
            if (k < pm.size) for (r in 0..7) for (c in 0..7) {
                val x = put(b, pieces[pm[k]], r, c) ?: continue
                any = true
                go(x.b, pm, k + 1, mv + Move(pm[k], r, c, pieces[pm[k]]), ln + x.n)
            }
            if (!any) {
                val s = eval(b, ln, mv.size, ps.size)
                if (s > best) { best = s; res = Result(mv, ln) }
            }
        }
        for (pm in perms(ps)) go(board.copyOf(), pm, 0, emptyList(), 0)
        return res
    }
}
