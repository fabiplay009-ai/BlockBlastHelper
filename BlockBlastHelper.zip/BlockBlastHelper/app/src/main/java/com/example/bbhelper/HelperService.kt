package com.example.bbhelper

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.*
import android.hardware.display.DisplayManager
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

class HelperService : Service() {
    // ---- Kalibrierung (Anteile von Bildschirmbreite W bzw. -höhe H) ----
    private val BX = 0.0574f  // Brett: linker Rand (x W)
    private val BY = 0.2417f  // Brett: oberer Rand (x H)
    private val BS = 0.885f   // Brett: Breite (x W)
    private val TY0 = 0.71f   // Ablage der Teile: oben (x H)
    private val TY1 = 0.90f   // Ablage der Teile: unten (x H)
    private val TS = 0.45f    // Feldgröße in der Ablage relativ zum Brettfeld
    private val MIND = 100    // Teil erkannt, wenn Farbabstand zum Ablage-Hintergrund größer ist

    private val COL = intArrayOf(0xAA2F7BF5.toInt(), 0xAA0FA77A.toInt(), 0xAAE8890C.toInt())
    private val h = Handler(Looper.getMainLooper())
    private var W = 0
    private var H = 0
    private lateinit var wm: WindowManager
    private lateinit var reader: ImageReader
    private lateinit var btn: TextView
    private lateinit var ov: Ov
    private var mp: MediaProjection? = null

    private class Item(val r: RectF, val color: Int, val txt: String?, val stroke: Boolean)

    private class Ov(c: Context) : View(c) {
        val items = ArrayList<Item>()
        private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; textSize = 44f; strokeWidth = 4f }
        override fun onDraw(cv: Canvas) {
            for (i in items) {
                p.style = if (i.stroke) Paint.Style.STROKE else Paint.Style.FILL
                p.color = i.color
                cv.drawRoundRect(i.r, 10f, 10f, p)
                if (i.txt != null) {
                    p.style = Paint.Style.FILL; p.color = Color.WHITE
                    cv.drawText(i.txt, i.r.centerX(), i.r.centerY() + 15f, p)
                }
            }
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    private fun lp(w: Int, hh: Int, flags: Int) =
        WindowManager.LayoutParams(w, hh, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT)

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("bb", "Block-Helfer", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "bb").setContentTitle("Block-Helfer läuft")
            .setSmallIcon(android.R.drawable.ic_menu_view).build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        @Suppress("DEPRECATION")
        val data = i?.getParcelableExtra<Intent>("data") ?: return START_NOT_STICKY
        wm = getSystemService(WindowManager::class.java)
        val b = wm.maximumWindowMetrics.bounds
        W = b.width(); H = b.height()
        mp = getSystemService(MediaProjectionManager::class.java).getMediaProjection(i.getIntExtra("code", 0), data)
        mp!!.registerCallback(object : MediaProjection.Callback() { override fun onStop() { stopSelf() } }, h)
        reader = ImageReader.newInstance(W, H, PixelFormat.RGBA_8888, 2)
        mp!!.createVirtualDisplay("bb", W, H, resources.displayMetrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.surface, null, h)

        ov = Ov(this)
        wm.addView(ov, lp(-1, -1, 8 or 16 or 256 or 512).apply {
            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        })
        btn = TextView(this).apply {
            text = "▶ Zug"; setTextColor(Color.WHITE); setPadding(32, 20, 32, 20)
            setBackgroundColor(0xCC2D3280.toInt())
            setOnClickListener { analyze() }
            setOnLongClickListener { stopSelf(); true }  // lange drücken = beenden
        }
        wm.addView(btn, lp(-2, -2, 8).apply { gravity = Gravity.TOP or Gravity.START; y = 300 })
        return START_NOT_STICKY
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_LONG).show()

    private fun analyze() {
        ov.items.clear(); ov.invalidate(); btn.visibility = View.INVISIBLE
        h.postDelayed({
            val img = reader.acquireLatestImage()
            btn.visibility = View.VISIBLE
            if (img == null) { toast("Kein Bild, bitte nochmal tippen"); return@postDelayed }
            try {
                val buf = img.planes[0].buffer
                val rs = img.planes[0].rowStride
                fun rgb(x: Int, y: Int): IntArray {
                    val o = y.coerceIn(0, H - 1) * rs + x.coerceIn(0, W - 1) * 4
                    return intArrayOf(buf.get(o).toInt() and 255, buf.get(o + 1).toInt() and 255, buf.get(o + 2).toInt() and 255)
                }
                fun dist(a: IntArray, b: IntArray): Double {
                    val dr = a[0] - b[0]; val dg = a[1] - b[1]; val db = a[2] - b[2]
                    return sqrt((dr * dr + dg * dg + db * db).toDouble())
                }
                val bx = BX * W; val by = BY * H; val cs = BS * W / 8
                // Brett: Durchschnittsfarbe je Feld, dann 2 Gruppen bilden (leer = dunklere Gruppe)
                val avg = Array(64) { i ->
                    val sum = IntArray(3)
                    for (dy in -1..1) for (dx in -1..1) {
                        val c = rgb((bx + (i % 8 + .5f + dx * .25f) * cs).toInt(), (by + (i / 8 + .5f + dy * .25f) * cs).toInt())
                        for (k in 0..2) sum[k] += c[k]
                    }
                    IntArray(3) { sum[it] / 9 }
                }
                var lo = avg.minByOrNull { it[0] * 3 + it[1] * 6 + it[2] }!!
                var hi = avg.maxByOrNull { it[0] * 3 + it[1] * 6 + it[2] }!!
                var isHi = BooleanArray(64)
                for (iter in 0 until 6) {
                    isHi = BooleanArray(64) { i -> dist(avg[i], hi) < dist(avg[i], lo) }
                    for (sel in booleanArrayOf(false, true)) {
                        val sum = IntArray(3); var n = 0
                        for (i in 0 until 64) if (isHi[i] == sel) { n++; for (k in 0..2) sum[k] += avg[i][k] }
                        if (n > 0) { val m = IntArray(3) { sum[it] / n }; if (sel) hi = m else lo = m }
                    }
                }
                val board = if (dist(lo, hi) < 60) BooleanArray(64) else isHi
                // Ablage: Teil = Pixel, der sich deutlich vom Hintergrund des Feldes unterscheidet
                val pieces = (0..2).map { s ->
                    val x0 = W * s / 3; val x1 = W * (s + 1) / 3
                    val y0 = (TY0 * H).toInt(); val y1 = (TY1 * H).toInt()
                    val bg = rgb(x0 + 20, y1 - 20)
                    fun on(x: Int, y: Int) = dist(rgb(x, y), bg) > MIND
                    var mnX = Int.MAX_VALUE; var mnY = Int.MAX_VALUE; var mxX = -1; var mxY = -1
                    for (y in y0 + 10 until y1 - 30 step 4) for (x in x0 + 10 until x1 - 10 step 4) if (on(x, y)) {
                        mnX = min(mnX, x); mxX = max(mxX, x); mnY = min(mnY, y); mxY = max(mxY, y)
                    }
                    val cells = ArrayList<IntArray>()
                    if (mxX >= 0) {
                        val w = (mxX - mnX + 4).toFloat(); val ph = (mxY - mnY + 4).toFloat()
                        val cols = (w / (cs * TS)).roundToInt().coerceIn(1, 5)
                        val rows = (ph / (cs * TS)).roundToInt().coerceIn(1, 5)
                        for (r in 0 until rows) for (c in 0 until cols)
                            if (on((mnX + (c + .5f) * w / cols).toInt(), (mnY + (r + .5f) * ph / rows).toInt())) cells.add(intArrayOf(r, c))
                    }
                    cells as List<IntArray>
                }
                // Kalibrierhilfe: weißer Rahmen = Brett, graue Rahmen = Ablage
                ov.items.add(Item(RectF(bx, by, bx + 8 * cs, by + 8 * cs), Color.WHITE, null, true))
                for (s in 0..2) ov.items.add(Item(RectF(W * s / 3f, TY0 * H, W * (s + 1) / 3f, TY1 * H), Color.GRAY, null, true))
                val res = Solver.solve(board, pieces)
                if (res == null) toast("Keine Teile erkannt. Kalibrierung prüfen.") else {
                    res.moves.forEachIndexed { n, m ->
                        for (x in m.cells) {
                            val l = bx + (m.c + x[1]) * cs; val t = by + (m.r + x[0]) * cs
                            ov.items.add(Item(RectF(l + 3, t + 3, l + cs - 3, t + cs - 3), COL[m.piece], "${n + 1}", false))
                        }
                    }
                    if (res.moves.size < pieces.count { it.isNotEmpty() }) toast("Achtung: nicht alle Teile passen.")
                }
                ov.invalidate()
            } finally { img.close() }
        }, 250)
    }

    override fun onDestroy() {
        try { wm.removeView(btn); wm.removeView(ov) } catch (_: Exception) {}
        mp?.stop()
        super.onDestroy()
    }
}
