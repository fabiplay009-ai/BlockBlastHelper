package com.example.bbhelper

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.*
import android.hardware.display.DisplayManager
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

class HelperService : Service() {
    // ---- Kalibrierung (Anteile von Bildschirmbreite W bzw. -höhe H) ----
    private val BX = 0.04f    // Brett: linker Rand (x W)
    private val BY = 0.27f    // Brett: oberer Rand (x H)
    private val BS = 0.92f    // Brett: Breite (x W)
    private val TY0 = 0.72f   // Ablage der Teile: oben (x H)
    private val TY1 = 0.90f   // Ablage der Teile: unten (x H)
    private val TS = 0.55f    // Feldgröße in der Ablage relativ zum Brettfeld
    private val MINV = 0.62f  // Mindesthelligkeit eines belegten Feldes
    private val MINS = 0.35f  // Mindestsättigung eines belegten Feldes

    private val COL = intArrayOf(0xAA2F7BF5.toInt(), 0xAA0FA77A.toInt(), 0xAAE8890C.toInt())
    private val h = Handler(Looper.getMainLooper())
    private var W = 0
    private var H = 0
    private lateinit var wm: WindowManager
    private lateinit var reader: ImageReader
    private lateinit var btn: TextView
    private lateinit var ov: Ov
    private var mp: MediaProjection? = null

    private class Item(val r: RectF, val color: Int, val txt: String?, val stroke: Boolean)

    private class Ov(c: Context) : View(c) {
        val items = ArrayList<Item>()
        private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; textSize = 44f; strokeWidth = 4f }
        override fun onDraw(cv: Canvas) {
            for (i in items) {
                p.style = if (i.stroke) Paint.Style.STROKE else Paint.Style.FILL
                p.color = i.color
                cv.drawRoundRect(i.r, 10f, 10f, p)
                if (i.txt != null) {
                    p.style = Paint.Style.FILL; p.color = Color.WHITE
                    cv.drawText(i.txt, i.r.centerX(), i.r.centerY() + 15f, p)
                }
            }
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    private fun lp(w: Int, hh: Int, flags: Int) =
        WindowManager.LayoutParams(w, hh, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT)

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("bb", "Block-Helfer", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "bb").setContentTitle("Block-Helfer läuft")
            .setSmallIcon(android.R.drawable.ic_menu_view).build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        @Suppress("DEPRECATION")
        val data = i?.getParcelableExtra<Intent>("data") ?: return START_NOT_STICKY
        wm = getSystemService(WindowManager::class.java)
        val b = wm.maximumWindowMetrics.bounds
        W = b.width(); H = b.height()
        mp = getSystemService(MediaProjectionManager::class.java).getMediaProjection(i.getIntExtra("code", 0), data)
        mp!!.registerCallback(object : MediaProjection.Callback() { override fun onStop() { stopSelf() } }, h)
        reader = ImageReader.newInstance(W, H, PixelFormat.RGBA_8888, 2)
        mp!!.createVirtualDisplay("bb", W, H, resources.displayMetrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.surface, null, h)

        ov = Ov(this)
        wm.addView(ov, lp(-1, -1, 8 or 16 or 256 or 512).apply {
            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        })
        btn = TextView(this).apply {
            text = "▶ Zug"; setTextColor(Color.WHITE); setPadding(32, 20, 32, 20)
            setBackgroundColor(0xCC2D3280.toInt())
            setOnClickListener { analyze() }
            setOnLongClickListener { stopSelf(); true }  // lange drücken = beenden
        }
        wm.addView(btn, lp(-2, -2, 8).apply { gravity = Gravity.TOP or Gravity.START; y = 300 })
        return START_NOT_STICKY
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_LONG).show()

    private fun analyze() {
        ov.items.clear(); ov.invalidate(); btn.visibility = View.INVISIBLE
        h.postDelayed({
            val img = reader.acquireLatestImage()
            btn.visibility = View.VISIBLE
            if (img == null) { toast("Kein Bild, bitte nochmal tippen"); return@postDelayed }
            try {
                val buf = img.planes[0].buffer
                val rs = img.planes[0].rowStride
                fun px(x: Int, y: Int): Boolean {
                    val o = y.coerceIn(0, H - 1) * rs + x.coerceIn(0, W - 1) * 4
                    val r = buf.get(o).toInt() and 255
                    val g = buf.get(o + 1).toInt() and 255
                    val b = buf.get(o + 2).toInt() and 255
                    val mx = max(r, max(g, b)); val mn = min(r, min(g, b))
                    return mx >= MINV * 255 && (mx - mn) >= MINS * mx
                }
                val bx = BX * W; val by = BY * H; val cs = BS * W / 8
                val board = BooleanArray(64) { px((bx + (it % 8 + .5f) * cs).toInt(), (by + (it / 8 + .5f) * cs).toInt()) }
                val pieces = (0..2).map { s ->
                    val x0 = W * s / 3; val x1 = W * (s + 1) / 3
                    val y0 = (TY0 * H).toInt(); val y1 = (TY1 * H).toInt()
                    var mnX = Int.MAX_VALUE; var mnY = Int.MAX_VALUE; var mxX = -1; var mxY = -1
                    for (y in y0 until y1 step 4) for (x in x0 until x1 step 4) if (px(x, y)) {
                        mnX = min(mnX, x); mxX = max(mxX, x); mnY = min(mnY, y); mxY = max(mxY, y)
                    }
                    val cells = ArrayList<IntArray>()
                    if (mxX >= 0) {
                        val w = (mxX - mnX + 4).toFloat(); val ph = (mxY - mnY + 4).toFloat()
                        val cols = (w / (cs * TS)).roundToInt().coerceIn(1, 5)
                        val rows = (ph / (cs * TS)).roundToInt().coerceIn(1, 5)
                        for (r in 0 until rows) for (c in 0 until cols)
                            if (px((mnX + (c + .5f) * w / cols).toInt(), (mnY + (r + .5f) * ph / rows).toInt())) cells.add(intArrayOf(r, c))
                    }
                    cells as List<IntArray>
                }
                // Kalibrierhilfe: weißer Rahmen = Brett, graue Rahmen = Ablage
                ov.items.add(Item(RectF(bx, by, bx + 8 * cs, by + 8 * cs), Color.WHITE, null, true))
                for (s in 0..2) ov.items.add(Item(RectF(W * s / 3f, TY0 * H, W * (s + 1) / 3f, TY1 * H), Color.GRAY, null, true))
                val res = Solver.solve(board, pieces)
                if (res == null) toast("Keine Teile erkannt. Kalibrierung prüfen.") else {
                    res.moves.forEachIndexed { n, m ->
                        for (x in m.cells) {
                            val l = bx + (m.c + x[1]) * cs; val t = by + (m.r + x[0]) * cs
                            ov.items.add(Item(RectF(l + 3, t + 3, l + cs - 3, t + cs - 3), COL[m.piece], "${n + 1}", false))
                        }
                    }
                    if (res.moves.size < pieces.count { it.isNotEmpty() }) toast("Achtung: nicht alle Teile passen.")
                }
                ov.invalidate()
            } finally { img.close() }
        }, 250)
    }

    override fun onDestroy() {
        try { wm.removeView(btn); wm.removeView(ov) } catch (_: Exception) {}
        mp?.stop()
        super.onDestroy()
    }
}
